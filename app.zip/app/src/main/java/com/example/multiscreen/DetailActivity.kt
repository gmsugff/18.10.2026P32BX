package com.example.multiscreen

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.multiscreen.ui.theme.MultiscreenTheme

class DetailActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val userName = intent.getStringExtra("USER_NAME") ?: ""
        val userCity = intent.getStringExtra("USER_CITY") ?: ""

        setContent {
            MultiscreenTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    // Передаем контекст (this@DetailActivity) внутрь функции
                    DetailScreen(userName, userCity, activity = this@DetailActivity)
                }
            }
        }
    }
}

@Composable
fun DetailScreen(userName: String, userCity: String, activity: Activity) {
    var replyText by rememberSaveable { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = "Привет, $userName!", style = MaterialTheme.typography.headlineMedium)
        Text(text = "Твой любимый город: $userCity", style = MaterialTheme.typography.titleLarge)

        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = replyText,
            onValueChange = { replyText = it },
            label = { Text("Ответ") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                val returnIntent = Intent().apply {
                    putExtra("RETURN_MESSAGE", replyText)
                }
                // Используем activity для вызова методов
                activity.setResult(Activity.RESULT_OK, returnIntent)
                activity.finish()
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Отправить ответ")
        }

        Spacer(modifier = Modifier.height(8.dp))


        Button(onClick = { activity.finish() }, modifier = Modifier.fillMaxWidth()) {
            Text("Назад")
        }
    }
}